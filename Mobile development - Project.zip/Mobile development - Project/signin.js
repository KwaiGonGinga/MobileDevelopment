$(document).ready( function(){
    var fb = firebase.database().ref();

    $( "#signUpButton" ).click(function() {
        var email = $("#username").val();
        var password = $("#userInput").val();

        firebase.auth().createUserWithEmailAndPassword(email, password).catch(function(error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            // ...
        });
    });

    $("#signInButton").on('click', function(){
        alert( "Handler for sign IN .click called." );
        var email = $("#username").val();
        var password = $("#userInput").val();

        firebase.auth().signInWithEmailAndPassword(email, password).catch(function(error) {
            var errorCode = error.code;
            var errorMessage = error.message;
            alert(error.message);

        });
    });


    $("#cancelButton").on('click', function(){

        firebase.auth().signOut().then(function() {
        }, function(error) {
            alert(error);
        });
    })


});

